<?php

class IndexController extends BaseController
{
    public function index()
    {
        return "Hello World";
    }
}
